
#define C1 	(0.91746406)
#define S1 	(0.397818675)
#define TP 	(6.283185307179586)
#define deg2rad (1.74532925199e-02)
